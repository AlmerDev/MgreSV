import "./styles.css";

export const metadata = {
  title: {
    default: "MgreSV | Fast Media Downloader",
    template: "%s | MgreSV",
  },
  description:
    "Mgresv adalah tool online untuk convert video ke MP3, MP4, M4A, JPG, PNG, dan format lain langsung dari browser.",
  keywords: [
    "convert video ke mp3",
    "download video online",
    "convert mp4 ke mp3",
    "convert audio online",
    "download mp3 dari video",
    "download mp4 dari video",
    "download mp3 dari video tiktok",
    "download mp4 dari video tiktok",
    "download mp3 dari video instagram",
    "download mp4 dari video instagram",
    "download mp3 dari video facebook",
    "download mp4 dari video facebook",
    "download mp3 dari video tiktok",
    "download mp4 dari video tiktok",
    "download mp3 dari video instagram",
    "download mp4 dari video instagram",
    "download mp3 dari video facebook",
    "download mp4 dari video facebook",
    "tiktok downloader",
    "instagram downloader",
    "facebook downloader",
    "tiktok to mp3",
    "instagram to mp3",
    "facebook to mp3",
    "tiktok to mp4",
    "instagram to mp4",
    "facebook to mp4",
    "tiktok to mp3",
    "instagram to mp3",
    "facebook to mp3",
    "tiktok to mp4",
    "instagram to mp4",
    "facebook to mp4",
    "mgresv",
  ],
  robots: {
    index: true,
    follow: true,
  },
  icons: {
    icon: "/logo.png",
  },
  openGraph: {
    title: "MgreSV",
    description: "Fast Media Downloader untuk video, audio, foto, dan slide.",
    siteName: "MgreSV",
    type: "website",
    images: [
      {
        url: "/logo.png",
        width: 512,
        height: 512,
        alt: "MgreSV",
      },
    ],
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
