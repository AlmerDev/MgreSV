// web/app/robots.js

export default function robots() {
  const baseUrl =
    process.env.NEXT_PUBLIC_SITE_URL || "https://mgresv.vercel.app";

  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/api/", "/files/", "/tmp/"],
      },
    ],
    sitemap: `${baseUrl}/sitemap.xml`,
  };
}
